<?php
die(header("Location: /"));